# SplatWalk Storage Adapter kit

Babylon Playground paste + quick ref for streamed SOG (`lod-meta.json`) via the Storage Adapter pattern.

## Contents

- `storage-adapter.ts` — Playground TypeScript paste (host owns Engine)
- `STORAGE_ADAPTER_QUICK_REF.ts`
- `STORAGE_ADAPTER_README.md`

## Vue demo

Full UI with WebGPU/WebGL toggle: `/storage-adapter` in the SplatWalk site.

## Renderer

The Playground **host** creates WebGL or WebGPU. Enable WebGPU in Playground settings when available.
For the Vue demo, use Stream settings → WebGPU / WebGL or `?renderer=`.
WebGPU needs raised `maxColorAttachmentBytesPerSample` (SplatWalk uses `setMaximumLimits`).
