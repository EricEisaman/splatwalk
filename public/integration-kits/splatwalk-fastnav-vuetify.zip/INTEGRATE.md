# SplatWalk FastNav — Vuetify + Babylon kit

Drop-in reference for the Vue / Vuetify Fast Nav showcase.

## Install

```bash
npm install @splatwalk/core @babylonjs/core vue vuetify
```

Peer UI: Vuetify 3+, Vue 3+, Babylon.js 9+.

## Files in this kit

- `src/components/vuetify/SplatFastNavShowcase.vue` — showcase card UI
- `src/composables/useSplatFastNav.ts` — Fast Nav orchestration
- `src/composables/useBabylonViewer.ts` — canvas / engine lifecycle
- `src/scene/createBabylonEngine.ts` — WebGPU (with GS MRT limits) + WebGL fallback

You still need the shared pipeline modules from the SplatWalk repo (or publish path):
`src/navigation/fastNav.ts`, `src/navigation/floor.ts`, `src/scene/Viewer.ts`, WASM bridge.
Prefer `npm install @splatwalk/core` for the WASM/floor contract and copy or vendor the showcase glue.

## Renderer

Babylon demos prefer WebGPU with WebGL fallback. Use `?renderer=webgl|webgpu` or the in-demo toggle.
WebGPU requests `setMaximumLimits` so `maxColorAttachmentBytesPerSample` can host the GS work-buffer MRT.

## Docs

- https://github.com/EricEisaman/splatwalk/blob/main/docs/INTEGRATION.md
- Live demo: `/vuetify`
