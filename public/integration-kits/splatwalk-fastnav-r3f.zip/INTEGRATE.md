# SplatWalk FastNav — React Three Fiber kit

Reference R3F / three.js Fast Nav showcase (mirrors the Vuetify demo).

## Install

```bash
npm install @splatwalk/core three @react-three/fiber @react-three/drei @mkkellogg/gaussian-splats-3d recast-navigation react react-dom @mui/material @emotion/react @emotion/styled
```

## Files in this kit

- `src/react/SplatFastNavShowcase.tsx`
- `src/react/useSplatFastNavR3F.ts`
- `src/react/SceneCanvas.tsx`
- `src/react/three/SplatNavController.ts`
- `src/react/exampleScenes.ts`

Wire WASM via `@splatwalk/core` / `@splatwalk/core/floor` as described in `examples/r3f/README.md`.

## Renderer

This path uses **Three.js WebGL** (`WebGLRenderer` + gaussian-splats-3d). There is no WebGPU splat path in this kit; demos show a WebGPU control disabled for clarity.

## Docs

- https://github.com/EricEisaman/splatwalk/blob/main/examples/r3f/README.md
- Live demo: `/react`
