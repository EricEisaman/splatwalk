# SplatWalk FastNav — Babylon workbench host kit

Minimal host wiring for `Viewer.create` + `runFastNav` (not the full homepage `splatwalk.ts`).

## Install

```bash
npm install @splatwalk/core @babylonjs/core
```

## Files

- `fastNavHost.snippet.ts` — sketch of engine create, load splat, run Fast Nav
- `createBabylonEngine.ts` — WebGPU/WebGL helper (copy into your host)

See `docs/INTEGRATION.md` for the full contract. Live advanced UI: `/` (3D Workbench).

## Renderer

Pass `renderer: 'webgpu' | 'webgl'` into `Viewer.create` / `createBabylonEngine`. Prefer WebGPU with `setMaximumLimits: true`.
