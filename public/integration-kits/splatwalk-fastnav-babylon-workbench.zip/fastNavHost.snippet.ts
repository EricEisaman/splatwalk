/**
 * Minimal Babylon host sketch for SplatWalk Fast Nav.
 * Copy patterns into your app; resolve imports against @splatwalk/core + your Viewer.
 */
import { createBabylonEngine, parseRendererPreference } from './createBabylonEngine';
// import { Viewer } from '...';
// import { runFastNav } from '...';

export async function bootFastNavHost(canvas: HTMLCanvasElement): Promise<void> {
  const preference = parseRendererPreference();
  const { engine, renderer, fallbackFromWebgpu } = await createBabylonEngine({
    canvas,
    preference,
  });
  console.info('[SplatWalk] Renderer:', renderer, fallbackFromWebgpu ? '(fallback)' : '');

  // const viewer = await Viewer.create(canvas, { renderer: preference, existing: { engine, scene } });
  // await viewer.loadSplat(bytes);
  // await runFastNav({ viewer, bytes, onLog: console.log });

  engine.runRenderLoop(() => {
    /* scene.render() */
  });
}
